/**
*The application's root package.
*Contains plural interfaces which are used at different levels of the Model-View-Controller architecture.
*/
package fr.sos.witchhunt;