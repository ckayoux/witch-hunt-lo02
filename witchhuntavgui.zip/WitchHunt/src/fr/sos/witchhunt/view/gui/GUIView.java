package fr.sos.witchhunt.view.gui;

public final class GUIView {

	Window w;
	
	//CONSTRUCTOR
	public GUIView () {
		//w = new Window();
	}
}
