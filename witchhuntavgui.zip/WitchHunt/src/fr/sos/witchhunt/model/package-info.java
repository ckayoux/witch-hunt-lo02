/**
 * This package contains all interfaces and classes that are used at plural levels of the MVC-architecture's model.
 */
package fr.sos.witchhunt.model;