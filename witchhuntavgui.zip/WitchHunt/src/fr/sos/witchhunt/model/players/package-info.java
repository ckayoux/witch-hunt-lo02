/**
 * This package's content consists of a definition of the elements representing the players, their possible actions within the game and their interactions with the view level of the MVC architecture.
 */
package fr.sos.witchhunt.model.players;